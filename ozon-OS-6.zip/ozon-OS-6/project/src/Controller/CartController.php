<?php

namespace App\Controller;

use App\Cart\API\CartAPIInterface;
use App\ServiceProvider;
use App\User\App\User;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;

class CartController extends AbstractController
{

    private CartAPIInterface $cartAPI;

    public function __construct(
        ServiceProvider $provider
    )
    {
        $this->cartAPI = $provider->getCartAPI();
    }

    public function add(int $productId): Response
    {
        $owner = $this->getUser();

        if(!$owner instanceof User)
        {
            return new Response(status: 500);
        }

        $this->cartAPI->addProductToCart($productId, (int) $owner->getUserIdentifier());

        return new Response(status: 200);
    }

    public function remove(int $productId): Response
    {
        $owner = $this->getUser();

        if (!$owner instanceof User) {
            return new Response(status: 500);
        }

        $this->cartAPI->deleteProductFromCart($productId, (int) $owner->getUserIdentifier());

        return new Response(status: 200);
    }
}
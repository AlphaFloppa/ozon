<?php

declare(strict_types=1);

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Cart\API\CartAPIInterface;
use App\ServiceProvider;
use App\User\App\User;

class UserController extends AbstractController
{
    private CartAPIInterface $cartAPI;

    public function __construct(
        ServiceProvider $provider
    ) {
        $this->cartAPI = $provider->getCartAPI();
    }

    public function profile(Request $request): Response
    {
        $user = $this->getUser();
        if(!$user instanceof User)
        {
            return new Response(status:500);
        }

        $cart = $this->cartAPI->findCart((int) $user->getUserIdentifier());

        return $this->render(
            'profile.html.twig',
            [
                'cart' => $cart->getCart()
            ]
        );
    }
}
<?php

namespace App\Cart\App\Query;

use App\Cart\App\Cart;

interface CartQueryServiceInterface
{
    public function findCartByUserId(int $id): Cart;
}
<?php

namespace App\Cart\App\Service;

interface CartServiceInterface
{
    public function addProductToCart(int $productId, int $ownerId): void;

    public function deleteProductFromCart(int $productId, int $ownerId): void;
}
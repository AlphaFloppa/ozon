<?php

namespace App\Cart\App\Repository;

use App\Cart\App\Cart;

interface CartRepositoryInterface
{
    public function addProductToCart(int $productId, int $ownerId): void;

    public function deleteProductFromCart(int $productId, int $ownerId): void;
}
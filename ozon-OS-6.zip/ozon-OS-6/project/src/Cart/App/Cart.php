<?php

namespace App\Cart\App;

class Cart
{
    /**
     * @var array array<int,array<{'product':ProductData(array),'quantity':int}>>
     */
    private array $cart;

    
    /**
     * @param array array<int,array<{'product':ProductData(array),'quantity':int}>>
     */
    public function __construct(
        array $cartItemsArray
    ) {
        $this->cart = $cartItemsArray;
    }

    public function getCart(): array
    {
        return $this->cart;
    }
}

<?php

namespace App\Cart\Infrastructure\Factory;

use App\Cart\API\CartAPI;
use App\Cart\Infrastructure\Query\CartQueryService;
use App\Cart\Infrastructure\Repository\CartRepository;
use App\Cart\Infrastructure\Service\CartService;
use PDO;

class CartAPIFactory
{
    public static function create(
        PDO $connection
    ): CartAPI {
        return new CartAPI(
            new CartQueryService($connection),
            new CartService($connection)
        );
    }
}
<?php

namespace App\Cart\Infrastructure\Repository;

use App\Cart\App\Repository\CartRepositoryInterface;
use PDO;

class CartRepository implements CartRepositoryInterface
{
    public function __construct(
        private PDO $pdo
    ) {}

    public function addProductToCart(int $productId, int $ownerId): void
    {
        $query = <<<SQL
            INSERT INTO cart_item
            (product_id, user_id)
            VALUES
            (:productId, :userId)
            ON DUPLICATE KEY UPDATE quantity = quantity + 1
        SQL;

        $stmt = $this->pdo->prepare($query);

        $stmt->execute(
            [
                'productId' => $productId,
                'userId' => $ownerId
            ]
        );
    }

    public function deleteProductFromCart(int $productId, int $ownerId): void
    {
        $query = <<<SQL
            UPDATE cart_item
            SET quantity = CASE
                WHEN quantity > 0
                    THEN quantity - 1
                    ELSE 0
                END;
            WHERE cart_item.product_id = :productId AND cart_item.user_id = :userId
        SQL;

        $stmt = $this->pdo->prepare($query);

        $stmt->execute(
            [
                'productId' => $productId,
                'userId' => $ownerId
            ]
        );
    }
}

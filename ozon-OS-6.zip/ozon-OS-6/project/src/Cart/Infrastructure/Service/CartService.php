<?php

namespace App\Cart\Infrastructure\Service;

use App\Cart\App\Repository\CartRepositoryInterface;
use App\Cart\App\Service\CartServiceInterface;
use App\Cart\Infrastructure\Repository\CartRepository;
use PDO;

class CartService implements CartServiceInterface
{   
    private CartRepositoryInterface $repository;
    public function __construct(
        PDO $pdo
    )
    {
        $this->repository = new CartRepository($pdo);
    }

    public function addProductToCart(int $productId, int $ownerId): void
    {
        $this->repository->addProductToCart($productId, $ownerId);
    }

    public function deleteProductFromCart(int $productId, int $ownerId): void
    {
        $this->repository->deleteProductFromCart($productId, $ownerId);
    }
}
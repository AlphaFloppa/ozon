<?php

namespace App\Cart\Infrastructure\Query;

use App\Cart\App\Cart;
use App\Cart\App\Query\CartQueryServiceInterface;
use PDO;

class CartQueryService implements CartQueryServiceInterface
{
    public function __construct(
        private PDO $pdo
    ) 
    {}

    public function findCartByUserId(int $id): Cart
    {
        $query = <<<SQL
            SELECT product.*, quantity FROM cart_item
            INNER JOIN product
            ON cart_item.product_id = product.id
            WHERE cart_item.user_id = :id AND cart_item.quantity > 0
        SQL;

        $stmt = $this->pdo->prepare($query);
        $stmt->execute(
            [
                'id' => $id,
            ]
        );

        $cartData = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $productsArray = array_map(
            fn($cartItemData) => [
                'product' => $this->hydrateProductData($cartItemData),
                'quantity' => (int) $cartItemData['quantity']
            ],
            $cartData
        );

        $cart = new Cart(
            $productsArray
        );

        return $cart;
    }

    private function hydrateProductData(array $data): array
    {
        return [
            'id' => $data['id'],
            'title' => $data['title'],
            'price' => (float) $data['price'],
            'description' => $data['description'],
            'image' => json_decode($data['images'])[0],
            'seller_id' => (string) $data['seller_id']
        ];
    }
}
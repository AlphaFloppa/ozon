<?php

namespace App\Cart\API;

use App\Cart\App\Cart;
use App\Cart\API\CartAPIInterface;
use App\Cart\App\Query\CartQueryServiceInterface;
use App\Cart\App\Service\CartServiceInterface;

class CartAPI implements CartAPIInterface
{
    public function __construct(
        private CartQueryServiceInterface $queryService,
        private CartServiceInterface $service
    )
    {}

    public function findCart(int $ownerId): Cart
    {
        return $this->queryService->findCartByUserId($ownerId);
    }

    public function addProductToCart(int $productId, int $ownerId): void
    {
        $this->service->addProductToCart($productId, $ownerId);
    }

    public function deleteProductFromCart(int $productId, int $ownerId): void
    {
        $this->service->deleteProductFromCart($productId, $ownerId);
    }
}
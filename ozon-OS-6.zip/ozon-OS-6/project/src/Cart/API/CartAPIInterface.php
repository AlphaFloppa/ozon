<?php

namespace App\Cart\API;

use App\Cart\App\Cart;

interface CartAPIInterface
{
    public function findCart(int $ownerId): Cart;

    public function addProductToCart(int $productId, int $ownerId): void;

    public function deleteProductFromCart(int $productId, int $ownerId): void;
}
<?php

declare (strict_types = 1);

namespace App\User\Infrastructure\Query;

use App\User\App\Query\UserQueryServiceInterface;
use App\User\App\User;
use PDO;

class UserQueryService implements UserQueryServiceInterface
{
    public function __construct
    (
        private PDO $pdo
    )
    {
        }

    public function findUserByEmail(string $email): ?User
    {
        $query = <<<SQL
            SELECT * FROM user
            WHERE email = :email
        SQL;
        $stmt = $this->pdo->prepare($query);
        $stmt->execute(
            [
                'email' => $email,
            ]
        );
        $userData = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$userData)
        {
            return null;
        }


        return new User(
            (string) $userData['id'],
            $email,
            $userData['password_hash'],
            (float) $userData['balance'],
            strtoupper($userData['role'])
        );
    }
}